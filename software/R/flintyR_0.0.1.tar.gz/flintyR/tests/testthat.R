library(testthat)
library(flintyR)

test_check("flintyR")
